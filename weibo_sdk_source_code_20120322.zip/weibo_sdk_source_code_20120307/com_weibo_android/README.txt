This is an Android Weibo SDK sample code. It enables you to request weibo api more simplely.

Features:

+ Login Weibo and get accessToken with your cunsumer key , secret, username, password.
+ Supports oauth and xauth ,two authorization methods.
+ Request any Weibo api by a simple request method
+ Share any content or image you want to Weibo.


FAQ:


+ What can I do with this?
You can access any information from weibo, as above.

+ Why would i need this SDK?
It make you develop an Weibo feature application easier than before.

+ How can i use it?
 Add the source code or .jar lib to your project, just follow the API doc. Also, you can read the code, Architecture is simple to be understanded.
 
    